CREATE TABLE cab (cabid NUMBER PRIMARY KEY, name VARCHAR2 (20), pincode varchar2(6));
INSERT INTO cab VALUES(1001,�Tata Indica�,'600157');
INSERT INTO cab VALUES(1002,�Mahindra�,'688157');
INSERT INTO cab VALUES(1003,�Hyundai Xcent�,'612157');
//TO DO � INSERT few more mobile details.


CREATE TABLE cabcustomer(customerid NUMBER, name vARCHAR2(20), address VARCHAR2(30),phoneno VARCHAR2(20), regdate DATE, pin varchar2(6));

CREATE SEQUENCE customer_sequence
START WITH 1;



