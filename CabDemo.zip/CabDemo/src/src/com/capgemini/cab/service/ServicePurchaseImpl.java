package src.com.capgemini.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.mobpur.bean.PurchaseDetailsBean;
import com.capgemini.mobpur.dao.IMobileDAO;
import com.capgemini.mobpur.dao.IPurchaseDetailsDAO;
import com.capgemini.mobpur.dao.MobileDAOImpl;
import com.capgemini.mobpur.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobpur.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws CabException {
		int mobileQuantity = 0;
		boolean isItInserted = false;
		boolean isUpdated = false;
		IPurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOImpl();
		ICustomerDAO mobileDAO = new MobileDAOImpl();
		
		mobileQuantity = mobileDAO.getQuantity(purchaseDetailsBean.getMobileId());
		
		if(mobileQuantity>0){
	    isItInserted = purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
	    mobileQuantity--;
	    isUpdated = mobileDAO.updateMobile(purchaseDetailsBean.getMobileId(),mobileQuantity);
		}
		return (isItInserted && isUpdated);
	}
	public boolean isValidCName(String cname) throws  CabException{
		boolean isValid = false;
		String pattern = "[A-Z]{1}[A-Za-z]{0,19}";
		Pattern p1=Pattern.compile(pattern);
		Matcher matcher = p1.matcher(cname);
		isValid = matcher.matches();
		if(!isValid){
			throw new CabException("Invalid Name");
		}
		return isValid;
	}
	public boolean isValidPhoneNo(String phoneNo) throws CabException
	{
		boolean isValid = false;
		String pattern = "[\\d]{10}";
		Pattern p1=Pattern.compile(pattern);
		Matcher matcher = p1.matcher(phoneNo);
		isValid = matcher.matches();
		if(!isValid){
			throw new CabException("Phone number must be 10 digits long");
		}
		return isValid;
	}
	public boolean isValidMail(String mail) throws CabException
	{
		boolean isValid = false;
		String pattern = "[a-z0-9,_%-]+@[a-z0-9,-]+\\.[a-z]{2,3}$";
		Pattern p1=Pattern.compile(pattern);
		Matcher matcher = p1.matcher(mail);
		isValid = matcher.matches();
		if(!isValid){
			throw new CabException("Invalid email id");
		}
		return isValid;
	}
}
