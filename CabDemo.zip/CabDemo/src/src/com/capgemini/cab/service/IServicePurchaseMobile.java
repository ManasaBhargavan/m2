package src.com.capgemini.cab.service;

import java.util.List;

import com.capgemini.mobpur.bean.MobileBean;
import com.capgemini.mobpur.bean.PurchaseDetailsBean;
import com.capgemini.mobpur.exception.MobilePurchaseException;

public interface IServicePurchaseMobile {
  public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
  throws CabException;
  
  //public List<MobileBean> viewAll() throws MobilePurchaseException;
 
}
