package src.com.capgemini.cab.exception;

public class CabException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2333507435654752766L;
     public CabException(){
    	 super();
     }
	public CabException(String arg0) {
		super(arg0);
		
	}
}
