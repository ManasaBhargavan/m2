package src.com.capgemini.cab.dao;

import java.util.List;

import src.com.capgemini.cab.bean.CustomerBean;
import src.com.capgemini.cab.exception.CabException;



public interface ICustomerDAO {
     public boolean insertCustomer(final CustomerBean customerBean )
     throws CabException;
     
     public int viewCabs(String pin)throws CabException;
     
     
     public int getID() throws CabException;
}
