package com.capgemini.EmpDet.bean;

import java.sql.Date;

public class EmployeeDetailBean {
     private int empid;
     private String empname;
     private double empsalary;
     private String empDept;
     private String empDesg;
     private Date empdate;
	public EmployeeDetailBean() {
		super();
	}
	public EmployeeDetailBean( String empname, double empsalary,
			String empDept, String empDesg, Date empdate) {
		super();
		//this.empid = empid;
		this.empname = empname;
		this.empsalary = empsalary;
		this.empDept = empDept;
		this.empDesg = empDesg;
		this.empdate = empdate;
	}
	public Date getEmpdate() {
		return empdate;
	}
	public void setEmpdate(Date empdate) {
		this.empdate = empdate;
	}
	public void setEmpsalary(double empsalary) {
		this.empsalary = empsalary;
	}
	
	public double getEmpsalary() {
		return empsalary;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmpDept() {
		return empDept;
	}
	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}
	public String getEmpDesg() {
		return empDesg;
	}
	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}
	@Override
	public String toString() {
		return "EmployeeDetailBean [empid=" + empid + ", empname=" + empname
				+ ", empsalary=" + empsalary + ", empDept=" + empDept
				+ ", empDesg=" + empDesg + ", empdate=" + empdate + "]";
	}
	
	
     
}
