package com.capgemini.EmpDet.pi;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.EmpDet.bean.EmployeeDetailBean;
import com.capgemini.EmpDet.exception.EmployeeDetailsException;
import com.capgemini.EmpDet.service.ServiceEmployeeDetailsImpl;

public class EmployeeDetailsMain {
	private static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		
		boolean isInProcess = true;
		boolean isValid = false;
		byte choice = 0;
		
		String empname = null;
		String empDesg = null;
		String empDept = null;
		double empsalary = 0;
		String doj = null;
		int empid = 0;
		
		
		ServiceEmployeeDetailsImpl serviceemployee = new ServiceEmployeeDetailsImpl();
		EmployeeDetailBean employeedetailbean = null;
		
		List<EmployeeDetailBean>employeeList = null;
		Scanner scInput = new Scanner(System.in);
		
		
		while(isInProcess){
			System.out.println("Employee Details");
			System.out.println("1. Insert Employee Details.");
			System.out.println("2. Search for an employee detail.");
			System.out.println("3. Update employee detail");
			System.out.println("4. Delete employee details.");
			System.out.println("5. View details of all employee.");
			System.out.println("0. Exit.");
			System.out.println("Enter your choice");
			choice = Byte.parseByte(scInput.nextLine());
			switch(choice){
		
case 1:
				while(!isValid){
					try{
						System.out.println("Enter the employee name:");
						empname = scInput.nextLine();
						
						isValid = serviceemployee.isValidfield(empname);
					}catch(EmployeeDetailsException e){
						logger.error("Invalid name"+empname);
						isValid = false;
					}
				}
					
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter the salary:");
						empsalary = scInput.nextDouble();
						scInput.nextLine();

						isValid = serviceemployee.isValidempsalary(empsalary);
					}catch(EmployeeDetailsException e){
						logger.error("Invalid salary"+empsalary);
						System.err.println("Please enter a positive value");
						isValid = false;
						
					}
				}
					
				isValid = false;
				while(!isValid){
					try{
				System.out.println("Enter the Department:");
				empDept = scInput.nextLine();
				//scInput.next();
				isValid = serviceemployee.isValidDept(empDept);
				
					}catch(EmployeeDetailsException e){
						logger.error("Invalid Department"+empDept);
						isValid = false;
						
					}
				}
					
				isValid = false;
				while(!isValid){
					try{
				
				System.out.println("Enter the Designation:");
				
				empDesg = scInput.nextLine();
				isValid = serviceemployee.isValidfield(empDesg);
					}catch(EmployeeDetailsException e){
						logger.error("Invalid Designation"+empDesg);
						isValid = false;
						
					}
				}
				
				
						DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				System.out.println("Enter the Date of joining in dd/MM/yyyy:");
				
				doj = scInput.nextLine();
				TemporalAccessor ta = dtf.parse(doj);
				
				LocalDate dojdate = LocalDate.from(ta);
				
				java.sql.Date translateDate = java.sql.Date.valueOf(dojdate);
				employeedetailbean = new EmployeeDetailBean(empname,empsalary,empDept,empDesg,translateDate);
				
		try{
			serviceemployee.addEmployee(employeedetailbean);
			}catch(EmployeeDetailsException e){
			logger.error(e.getMessage());
		}
		break;
			
			
case 2:
	
	System.out.println("Enter employee id");
	empid = Integer.parseInt(scInput.nextLine());
	try{
		employeeList = serviceemployee.searchEmployee(empid);
		

	for(EmployeeDetailBean employeedetailBean : employeeList){
		System.out.println(employeedetailBean);
	}
	System.out.println("================================================");
	}catch(EmployeeDetailsException e){
		logger.error(e.getMessage());
	}
	break;
case 3:isValid = false;
	 while(!isValid){
		    try{
			System.out.println("Enter employee id:");
			empid = Integer.parseInt(scInput.nextLine());
			
			isValid = serviceemployee.isValidempid(empid);
			
		
		    }catch(EmployeeDetailsException mpe){
				logger.error("Invalid employee id: "+empsalary);
				isValid = false;
		    }
	 }
		    System.out.println("Enter salary:");
			empsalary = scInput.nextDouble();
			scInput.nextLine();
		    try{
		    boolean isUpdated = serviceemployee.updateEmployee(empid,empsalary);
		    if(isUpdated){
			System.out.println("Mobile record updated successfully!");
		    }
		    else
		    {
		    	throw new EmployeeDetailsException();
		    }
		    }catch(EmployeeDetailsException e){
			logger.error(e.getMessage());
		    }
	 
			break;
	
	
case 4:isValid = false;

    while(!isValid){
    try{
	System.out.println("Enter employee id:");
	empid = Integer.parseInt(scInput.nextLine());
	
	isValid = serviceemployee.isValidempid(empid);
    }catch(EmployeeDetailsException mpe){
	logger.error("Invalid mobile id: "+empid);
	isValid = false;
	
    }
    }
    try{
    boolean isDeleted = serviceemployee.deleteEmployee(empid);
    if(isDeleted){
	System.out.println("Mobile record deleted successfully!");
    }
    }catch(EmployeeDetailsException e){
	logger.error(e.getMessage());
    }

	break;
	
	
case 5:
	
	try{
		employeeList = serviceemployee.viewAllEmployees();
		for(EmployeeDetailBean eb : employeeList){
			System.out.println(eb);
		}
		System.out.println("==============================================");
		}catch(EmployeeDetailsException e){
			logger.error(e.getMessage());
		}
		
			break;		
			
case 0:
	isInProcess = false;
	break;
default:
	System.out.println("Invalid input");
	logger.error("Invalid input: "+choice);
	break;
			
			}
		}
		scInput.close();
	}
}
