package com.capgemini.EmpDet.exception;

public class EmployeeDetailsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4631839954796587622L;
    public EmployeeDetailsException(){
    	super();
    }
    public EmployeeDetailsException(String message){
    	super(message);
    }
}
