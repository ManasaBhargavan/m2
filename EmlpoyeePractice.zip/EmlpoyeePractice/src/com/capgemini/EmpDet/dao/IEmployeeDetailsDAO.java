package com.capgemini.EmpDet.dao;

import java.util.List;

import com.capgemini.EmpDet.bean.EmployeeDetailBean;
import com.capgemini.EmpDet.exception.EmployeeDetailsException;

public interface IEmployeeDetailsDAO {
  public boolean addEmployee(final EmployeeDetailBean employeedetail)
   throws EmployeeDetailsException;
  public List<EmployeeDetailBean> searchEmployee(final int empid)
   throws EmployeeDetailsException;
  public boolean updateEmployee(final int empid,final double empsalary)
		  throws EmployeeDetailsException;
  public boolean deleteEmployee(final int empid)
		  throws EmployeeDetailsException;
  public List<EmployeeDetailBean> viewAllEmployees()
		  throws EmployeeDetailsException;
}
