package com.capgemini.EmpDet.dao;

public interface QueryMapperEmployeeDetails {
  public static final String ADD_EMPLOYEE= "INSERT INTO employeeDetails VALUES (emp_id_seq.nextVal,?,?,?,?,?)";
  public static final String SEARCH_EMPLOYEE= "SELECT * FROM employeeDetails WHERE empid=?";
  public static final String UPDATE_EMPLOYEE= "UPDATE  employeeDetails SET empsalary=? WHERE empid=?";
  public static final String DELETE_EMPLOYEE= "DELETE FROM employeeDetails WHERE empid=?";
  public static final String VIEW_EMPLOYEE= "SELECT * FROM employeeDetails";
  
}
