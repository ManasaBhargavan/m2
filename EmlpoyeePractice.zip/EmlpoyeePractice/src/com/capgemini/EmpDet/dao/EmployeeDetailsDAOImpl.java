package com.capgemini.EmpDet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.EmpDet.bean.EmployeeDetailBean;
import com.capgemini.EmpDet.exception.EmployeeDetailsException;
import com.capgemini.EmpDet.util.DBConnection;


public class EmployeeDetailsDAOImpl implements IEmployeeDetailsDAO {
	@Override
	public boolean addEmployee(EmployeeDetailBean employeedetail)
			throws EmployeeDetailsException{
		int records = 0;
		boolean isadded = false;
		
		try(Connection connEmployeeDetail  = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
		connEmployeeDetail.prepareStatement(QueryMapperEmployeeDetails.ADD_EMPLOYEE);
	){
			
			preparedStatement.setString(1, employeedetail.getEmpname());
			preparedStatement.setDouble(2, employeedetail.getEmpsalary());
			preparedStatement.setString(3, employeedetail.getEmpDept());
			preparedStatement.setString(4, employeedetail.getEmpDesg());
			preparedStatement.setDate(5, employeedetail.getEmpdate());
		records = preparedStatement.executeUpdate();
		if(records>0){
			isadded= true;
		}
		
	}catch(SQLException sqlEx){
		throw new EmployeeDetailsException(sqlEx.getMessage());
	}
	return isadded;
	}

	@Override
	public List<EmployeeDetailBean> searchEmployee(int empid)
			throws EmployeeDetailsException {
		
			List<EmployeeDetailBean>employeeList = new ArrayList<EmployeeDetailBean>();
			
			try(Connection connEmployeeDetail  = DBConnection.getInstance().getConnection();	
			
			PreparedStatement preparedStatement=
			connEmployeeDetail.prepareStatement(QueryMapperEmployeeDetails.SEARCH_EMPLOYEE);
					
		){
				 preparedStatement.setInt(1,empid);
				ResultSet rsemployeedetails = preparedStatement.executeQuery();
			
			while(rsemployeedetails.next()){
				EmployeeDetailBean employee = new EmployeeDetailBean();
				
				employee.setEmpid(rsemployeedetails.getInt("empid"));
			employee.setEmpname(rsemployeedetails.getString("empname"));
				employee.setEmpsalary(rsemployeedetails.getInt("empsalary"));
				employee.setEmpDept(rsemployeedetails.getString("empDept"));
				employee.setEmpDesg(rsemployeedetails.getString("empDesg"));
				employee.setEmpdate(rsemployeedetails.getDate("empDate"));
				
				employeeList.add(employee);
			}
			if(employeeList.size() == 0){
				System.err.println("No records found");
				throw new EmployeeDetailsException("No records found.");
				
			}
		}catch(SQLException sqlEx){
			throw new EmployeeDetailsException(sqlEx.getMessage());
		}
		return employeeList;
		
	}
	
	@Override
	public boolean updateEmployee(int empid,double empsalary) throws EmployeeDetailsException {
		int records = 0;
		boolean isUpdated = false;
		
		try(Connection connEmployeeDetail  = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
		connEmployeeDetail.prepareStatement(QueryMapperEmployeeDetails.UPDATE_EMPLOYEE);
	){
		
			preparedStatement.setString(1, Double.toString(empsalary));
			preparedStatement.setInt(2, empid);
		records = preparedStatement.executeUpdate();
		if(records>0){
			isUpdated = true;
		}
		
	}catch(SQLException sqlEx){
		throw new EmployeeDetailsException (sqlEx.getMessage());
	}
		//
		System.out.println(isUpdated);
		//
	return isUpdated;
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeDetailsException {
		int records = 0;
		boolean isDeleted = false;
		
		try(Connection connEmployeeDetail  = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
		connEmployeeDetail.prepareStatement(QueryMapperEmployeeDetails.DELETE_EMPLOYEE);
	){
		
		preparedStatement.setInt(1, empid);
		
		records = preparedStatement.executeUpdate();
		if(records>0){
			isDeleted = true;
		}
		
	}catch(SQLException sqlEx){
		throw new EmployeeDetailsException(sqlEx.getMessage());
	}
	return isDeleted;
	}

	@Override
	public List<EmployeeDetailBean> viewAllEmployees()
			throws EmployeeDetailsException {
List<EmployeeDetailBean>employeeList = new ArrayList<EmployeeDetailBean>();
		
		try(Connection connEmployeeDetail  = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
		connEmployeeDetail.prepareStatement(QueryMapperEmployeeDetails.VIEW_EMPLOYEE);
		ResultSet rsemployeedetails = preparedStatement.executeQuery();
	){
			
		while(rsemployeedetails.next()){
			
			EmployeeDetailBean employee = new EmployeeDetailBean();
			employee.setEmpid(rsemployeedetails.getInt("empid"));
			employee.setEmpname(rsemployeedetails.getString("empname"));
			employee.setEmpsalary(rsemployeedetails.getInt("empsalary"));
			employee.setEmpDept(rsemployeedetails.getString("empdept"));
			employee.setEmpDesg(rsemployeedetails.getString("empdesg"));
			employee.setEmpdate(rsemployeedetails.getDate("doj"));
			
			employeeList.add(employee);
			
		}
		if(employeeList.size() == 0){
			throw new EmployeeDetailsException("No records found.");
		}
	}catch(SQLException sqlEx){
		throw new EmployeeDetailsException(sqlEx.getMessage());
	}
	return employeeList;
	}

}
