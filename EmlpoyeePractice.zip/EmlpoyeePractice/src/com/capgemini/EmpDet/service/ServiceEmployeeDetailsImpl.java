package com.capgemini.EmpDet.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.EmpDet.bean.EmployeeDetailBean;
import com.capgemini.EmpDet.dao.EmployeeDetailsDAOImpl;
import com.capgemini.EmpDet.dao.IEmployeeDetailsDAO;
import com.capgemini.EmpDet.exception.EmployeeDetailsException;



public class ServiceEmployeeDetailsImpl implements IServiceEmployeeDetails {
	private IEmployeeDetailsDAO EmployeeDetailsDAO;
	public ServiceEmployeeDetailsImpl(){
		EmployeeDetailsDAO = new EmployeeDetailsDAOImpl();
	}

	@Override
	public boolean addEmployee(EmployeeDetailBean employeedetail)
			throws EmployeeDetailsException {
		boolean isadded = EmployeeDetailsDAO.addEmployee(employeedetail);
		return isadded;
	}
	public boolean isValidfield(String field) throws  EmployeeDetailsException{
		boolean isValid = false;
		String pattern = "[A-Z]{1}[A-Za-z\\s]{2,19}";
		Pattern p1=Pattern.compile(pattern);
		Matcher matcher = p1.matcher(field);
		isValid = matcher.matches();
		if(!isValid){
			throw new EmployeeDetailsException("Invalid field");
		}
		return isValid;
	}
	public boolean isValidempsalary(double empsalary) throws  EmployeeDetailsException{
		boolean isValid = false;
		
		if(empsalary <= 0)
		{
			throw new EmployeeDetailsException();
		}
		else
		{
			isValid = true;
		}
		/*String salary=Double.toString(empsalary);
		String pattern = "[0-9.]{1}";
		Pattern p1=Pattern.compile(pattern);
		Matcher matcher = p1.matcher(salary);
		isValid = matcher.matches();*/
		if(!isValid){
			System.out.println("Error");
			throw new EmployeeDetailsException("Invalid Value");
		}
		return isValid;
	}
	
	public boolean isValidempid(int empid) throws EmployeeDetailsException
	{
		boolean isValid = false;
		String employee = Integer.toString(empid);
		String pattern = "[\\d]{4}";
		Pattern p1=Pattern.compile(pattern);
		Matcher matcher = p1.matcher(employee);
		isValid = matcher.matches();
		if(!isValid){
			throw new EmployeeDetailsException("Employee id must be 4 digits long");
		}
		return isValid;
	
	}
	
	public boolean isValidDept(String field) throws  EmployeeDetailsException{
		boolean isValid = false;
		
		
		
		for(Department dept : Department.values()){
			if(dept.name().equals(field)){
				isValid = true;
				break;
			}
			else
			{
				System.out.println("Error");
				throw new EmployeeDetailsException();
			}
		}
		if(!isValid){
			throw new EmployeeDetailsException("Invalid field");
		}
		return isValid;
	}
	
	

	@Override
	public List<EmployeeDetailBean> searchEmployee(int empid)
			throws EmployeeDetailsException {
		List<EmployeeDetailBean> Employeelist =EmployeeDetailsDAO.searchEmployee(empid);
		return Employeelist;
	}

	@Override
	public boolean updateEmployee(int empid,double empsalary)
			throws EmployeeDetailsException {
		IEmployeeDetailsDAO EmployeeDetailsDAO = new EmployeeDetailsDAOImpl();
		
		boolean isupdated = EmployeeDetailsDAO.updateEmployee(empid,empsalary);
		return isupdated;
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeDetailsException {
		IEmployeeDetailsDAO EmployeeDetailsDAO = new EmployeeDetailsDAOImpl();
		boolean isDeleted = EmployeeDetailsDAO.deleteEmployee(empid);
		return isDeleted ;
	}

	@Override
	public List<EmployeeDetailBean> viewAllEmployees()
			throws EmployeeDetailsException {
		List<EmployeeDetailBean>EmployeeList = EmployeeDetailsDAO.viewAllEmployees();
		return EmployeeList;
	}

}
