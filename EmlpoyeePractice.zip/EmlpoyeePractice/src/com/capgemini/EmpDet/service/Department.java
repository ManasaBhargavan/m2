package com.capgemini.EmpDet.service;

public enum Department {
	Accounts,Finance,Developer,HR
}
